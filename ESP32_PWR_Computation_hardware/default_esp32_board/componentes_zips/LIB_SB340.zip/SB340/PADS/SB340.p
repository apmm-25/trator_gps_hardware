*PADS-LIBRARY-PART-TYPES-V9*

SB340 DIOAD2510W125L750D440 I DIO 6 1 0 0 0
TIMESTAMP 2026.04.18.19.35.22
"Mouser Part Number" 637-SB340
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diotec-Semiconductor/SB340?qs=OlC7AqGiEDnR6Q%2FOOA%2FVPA%3D%3D
"Manufacturer_Name" Diotec
"Manufacturer_Part_Number" SB340
"Description" Schottky Diodes & Rectifiers Schottky, DO-201, 40V, 3A
"Datasheet Link" https://diotec.com/request/datasheet/sb320.pdf
GATE 1 2 0
SB340
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
2403591/1673336/2.50/2/3/Diode
