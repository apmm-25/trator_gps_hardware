*PADS-LIBRARY-PART-TYPES-V9*

M20-7821546 RHDR15W70P0X254_1X15_3850X250X850P I CON 7 1 0 0 0
TIMESTAMP 2026.04.18.21.09.38
"Mouser Part Number" 855-M20-7821546
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-7821546?qs=ulE8k0yEMYaXNbedAzK8cQ%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-7821546
"Description" M20: 15 Pos Receptacle SIL Straight 3mm THT Connector 8.5mm high Tin
"Datasheet Link" https://content.harwin.com/m/c2ac50ebb1c800d5/original/DRG-00385-Technical-Drawing-Datasheet-M20-782-pdf.pdf
"Geometry.Height" 8.5mm
GATE 1 15 0
M20-7821546
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10
11 0 U 11
12 0 U 12
13 0 U 13
14 0 U 14
15 0 U 15

*END*
*REMARK* SamacSys ECAD Model
661683/1673336/2.50/15/2/Connector
