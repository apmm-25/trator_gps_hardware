*PADS-LIBRARY-PART-TYPES-V9*

VLS6045EX-4R7M VLS6045 I IND 6 1 0 0 0
TIMESTAMP 2026.04.18.21.34.35
"Mouser Part Number" 810-VLS6045EX-4R7M
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/TDK/VLS6045EX-4R7M?qs=GtmDRopnxzp2p1TJ0mf3tQ%3D%3D
"Manufacturer_Name" TDK
"Manufacturer_Part_Number" VLS6045EX-4R7M
"Description" TDK VLS-EX Series Type 6045 Shielded Wire-wound SMD Inductor with a Ferrite Core, 4.7 uH Wire-Wound 4.2A Idc
"Datasheet Link" https://product.tdk.com/system/files/dam/doc/product/inductor/inductor/smd/catalog/inductor_commercial_power_vls6045ex_en.pdf
GATE 1 2 0
VLS6045EX-4R7M
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
548209/1673336/2.50/2/2/Inductor
