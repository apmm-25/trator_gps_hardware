*PADS-LIBRARY-PART-TYPES-V9*

LMR14020SSQDDAQ1 SOIC127P600X170-9N I ANA 7 1 0 0 0
TIMESTAMP 2026.04.12.23.22.52
"Mouser Part Number" 595-LMR14020SSQDDAQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMR14020SSQDDAQ1?qs=diC8vqfyxkp45LTZX%252BiGRA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMR14020SSQDDAQ1
"Description" Automotive 40V, 2A SIMPLE SWITCHER, 2.2MHz Step-Down Regulator with 40uA IQ
"Datasheet Link" http://www.ti.com/lit/gpn/LMR14020-Q1
"Geometry.Height" 1.7mm
GATE 1 9 0
LMR14020SSQDDAQ1
1 0 U BOOT
2 0 U VIN
3 0 U EN
4 0 U RT/SYNC
9 0 U EP
8 0 U SW
7 0 U GND
6 0 U SS
5 0 U FB

*END*
*REMARK* SamacSys ECAD Model
876206/1673336/2.50/9/3/Integrated Circuit
