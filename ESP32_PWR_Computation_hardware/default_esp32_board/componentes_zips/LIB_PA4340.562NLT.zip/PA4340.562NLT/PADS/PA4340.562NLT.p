*PADS-LIBRARY-PART-TYPES-V9*

PA4340.562NLT PA4340562NLT I IND 7 1 0 0 0
TIMESTAMP 2026.04.18.21.22.42
"Mouser Part Number" 673-PA4340.562NLT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Pulse-Electronics/PA4340.562NLT?qs=%2FzQKu7YvIMbDc4%252BFkENBNA%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" PA4340.562NLT
"Description" Fixed Inductors 5.6uH 4.25A 3mm 20% Low Prof
"Datasheet Link" 
"Geometry.Height" 3mm
GATE 1 2 0
PA4340.562NLT
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1050519/1673336/2.50/2/3/Inductor
