*PADS-LIBRARY-PART-TYPES-V9*

ERB-RG2R00V ERBRG4R00V I FUS 7 1 0 0 0
TIMESTAMP 2026.04.18.20.12.55
"Mouser Part Number" 667-ERB-RG2R00V
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/ERB-RG2R00V?qs=Z3CaLxJiOJIWtO5TO4iunA%3D%3D
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ERB-RG2R00V
"Description" Micro Chip Fuse, Size [LW] (EIA) (mm): 3.21.6 (EIA:1206), Rated Current (A): 2, Internal R [at 25 max.] (m): 85, Rated Voltage (Open Circuit Voltage) [DC] (V): 63, Interrupting Rating (A): 50, Category Temp. Range (C): -40 to +125
"Datasheet Link" https://industrial.panasonic.com/cdbs/www-data/pdf/AFA0000/AFA0000C7.pdf
"Geometry.Height" 0.75mm
GATE 1 2 0
ERB-RG2R00V
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1094821/1673336/2.50/2/2/Fuse
